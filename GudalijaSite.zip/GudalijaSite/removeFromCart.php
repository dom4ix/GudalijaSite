<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  // Pobierz dane przesłane przez żądanie AJAX
  $productName = $_POST["product_name"];

  // Połącz z bazą danych
  $servername = "localhost"; // Twój serwer MySQL
  $username = "root"; // Twój użytkownik MySQL
  $password = ""; // Twoje hasło MySQL
  $dbname = "Users"; // Twoja nazwa bazy danych

  $conn = new mysqli($servername, $username, $password, $dbname);
  if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
  }

  // Usuń produkt z koszyka
  $sql = "DELETE FROM cart WHERE product_name = '$productName'";
  if ($conn->query($sql) === TRUE) {
    echo "Success";
  } else {
    echo "Błąd podczas usuwania produktu z koszyka: " . $conn->error;
  }

  // Zamknij połączenie z bazą danych
  $conn->close();
}
?>

