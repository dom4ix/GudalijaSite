<?php
// Połącz z bazą danych
$servername = "localhost"; // Twój serwer MySQL
$username = "root"; // Twój użytkownik MySQL
$password = ""; // Twoje hasło MySQL
$dbname = "Users"; // Twoja nazwa bazy danych

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}

// Odczytaj dane z formularza
$name = $_POST['name'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$deliveryOption = $_POST['delivery'];
$paymentOption = $_POST['payment'];

// Wstaw dane zamówienia do tabeli orders
$insertOrderSql = "INSERT INTO orders (name, address, phone, delivery_option, payment_option) VALUES ('$name', '$address', '$phone', '$deliveryOption', '$paymentOption')";
$conn->query($insertOrderSql);

// Pobierz ID ostatnio wstawionego zamówienia
$orderId = $conn->insert_id;

// Przenieś produkty z koszyka do zamówienia
$sql = "SELECT cart.*, products.name AS product_name FROM cart JOIN products ON cart.product_id = products.id";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
  $productId = $row['product_id'];
  $productName = $row['product_name'];
  $productPrice = $row['price'];
  $quantity = $row['quantity'];

  $insertOrderItemSql = "INSERT INTO order_items (order_id, product_id, product_name, price, quantity) VALUES ('$orderId', '$productId', '$productName', '$productPrice', '$quantity')";
  $conn->query($insertOrderItemSql);
}

// Wyczyść koszyk po złożeniu zamówienia
$clearCartSql = "DELETE FROM cart";
$conn->query($clearCartSql);

// Zamknij połączenie z bazą danych
$conn->close();

// Przekieruj użytkownika na stronę z potwierdzeniem zamówienia lub wyświetl odpowiedni komunikat
header("Location: confirmation.php?order_id=$orderId");
exit();
?>
