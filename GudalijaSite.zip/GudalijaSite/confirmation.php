<!DOCTYPE html>
<html>
<head>
  <title>Potwierdzenie zamówienia</title>
  <style>
    /* stylizacja... */

  </style>
</head>
<body>

  <div>
    <h1>Potwierdzenie zamówienia</h1>
    <p>Dziękujemy za złożenie zamówienia! Oto szczegóły Twojego zamówienia:</p>

    <?php
    // Połącz z bazą danych
    $servername = "localhost"; // Twój serwer MySQL
    $username = "root"; // Twój użytkownik MySQL
    $password = ""; // Twoje hasło MySQL
    $dbname = "Users"; // Twoja nazwa bazy danych

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
      die("Błąd połączenia z bazą danych: " . $conn->connect_error);
    }

    // Sprawdź istnienie parametru order_id
    if (isset($_GET['order_id'])) {
      $orderId = $_GET['order_id'];

      // Pobierz szczegóły zamówienia
      $orderSql = "SELECT * FROM orders WHERE id = '$orderId'";
      $orderResult = $conn->query($orderSql);

      if ($orderResult->num_rows > 0) {
        $orderRow = $orderResult->fetch_assoc();
        $name = $orderRow['name'];
        $address = $orderRow['address'];
        $phone = $orderRow['phone'];
        $deliveryOption = $orderRow['delivery_option'];
        $paymentOption = $orderRow['payment_option'];

        echo "<p><strong>Imię:</strong> $name</p>";
        echo "<p><strong>Adres:</strong> $address</p>";
        echo "<p><strong>Telefon:</strong> $phone</p>";
        echo "<p><strong>Opcje dostawy:</strong> $deliveryOption</p>";
        echo "<p><strong>Opcje płatności:</strong> $paymentOption</p>";

        // Pobierz szczegóły zamówionych produktów
        $orderItemsSql = "SELECT * FROM order_items WHERE order_id = '$orderId'";
        $orderItemsResult = $conn->query($orderItemsSql);

        if ($orderItemsResult->num_rows > 0) {
          echo "<p><strong>Zamówione produkty:</strong></p>";
          echo "<ul>";
          while ($orderItemRow = $orderItemsResult->fetch_assoc()) {
            $productName = $orderItemRow['product_name'];
            $quantity = $orderItemRow['quantity'];

            echo "<li>$productName - Ilość: $quantity</li>";
          }
          echo "</ul>";
        } else {
          echo "<p>Brak zamówionych produktów.</p>";
        }
      } else {
        echo "<p>Nie znaleziono zamówienia o podanym identyfikatorze.</p>";
      }
    } else {
      echo "<p>Brak identyfikatora zamówienia.</p>";
    }

    // Zamknij połączenie z bazą danych
    $conn->close();
    ?>

  </div>

</body>
</html>
