<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  // Pobierz dane przesłane przez żądanie AJAX
  $productId = $_POST["product_id"];
  $productName = $_POST["product_name"];
  $productPrice = $_POST["product_price"];

  // Pobierz ID użytkownika z sesji
  $userId = $_SESSION["user_id"];

  // Połącz z bazą danych
  $servername = "localhost"; 
  $username = "root"; 
  $password = ""; 
  $dbname = "Users"; 

  $conn = new mysqli($servername, $username, $password, $dbname);
  if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
  }

  // Dodaj produkt do koszyka
  $sql = "INSERT INTO cart (user_id, product_id, product_name, price, quantity) VALUES (?, ?, ?, ?, 1)";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("iisd", $userId, $productId, $productName, $productPrice);

  if ($stmt->execute()) {
    echo "Success";
  } else {
    echo "Błąd podczas dodawania produktu do koszyka: " . $stmt->error;
  }

  // Zamknij połączenie z bazą danych
  $stmt->close();
  $conn->close();
}
?>