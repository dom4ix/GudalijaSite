<!DOCTYPE html>
<html>
<head>
  <title>Koszyk</title>
  <style>

:root {
  --primary-color: #f59e1d;
  --primary-color-dark: #fbbf24;
  --secondary-color: #2a80b3;
  --text-dark: #333333;
  --text-light: #f5f5f5;
  --white: #ffffff;
  --max-width: 1200px;
}

    html, body {
      height: 100%;
      margin: 0;
      padding: 0;
      background-image: url("/GudalijaSite/Style&IMG/assets/z.jpg");
    }

    .tablecart {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 300px; /* Wysokość strony minus 25 pikseli na odstęp */
      font-family: Arial, sans-serif;
    }

    h1 {
      height: 50px;
      text-align: center;
      color: var(--white);
      margin-top: 25px; /* Odstęp (góra) nad tytułem */
      margin-bottom: 20px;
    }

    table {
      border-collapse: collapse;
      width: 1100px;
      height: 550px;
      background-color: #f9f9f9;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
      margin-top: 20px;
      margin-left: auto;
      margin-right: auto;
    }

    table th,
    table td {
      padding: 10px;
      text-align: left;
    }

    table th {
      background-color: #333;
      color: #fff;
    }

    table td input {
      width: 50px;
    }

    table tfoot th {
      text-align: right;
      font-weight: bold;
    }

    .product-name {
      padding-right: 75px;
    }

    button {
    padding: 0.5rem 0.5rem;
    font-size: 1rem;
    color: var(--primary-color);
    outline: none;
    border: none;
    border-radius: 5px;
    background-color: var(--white);
    cursor: pointer;
    transition: 0.3s;
    }
    button:hover{
    background-color: var(--primary-color-dark);
    color: var(--text-light);
    }

    /* New styles for the form */
    form {
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    form label {
      display: block;
      text-align: center;
	  margin-top: 20px;
      color: var(--white);
    }

    form input,
    form select {
      width: 250px;
      padding: 5px;
    }

    form button[type="submit"] {
      width: 150px;
	  margin-top: 20px;
	  margin-bottom: 20px;

    }
	
  </style>
</head>
<body>

  <div class="tablecart">
  <h1>Shopping Cart</h1>
  <table>
    <thead>
      <tr>
        <th>Nazwa</th>
        <th>Cena</th>
        <th>Ilość</th>
        <th>Akcje</th>
        <th>Mod</th>
      </tr>
    </thead>
    <tbody>
      <?php
      // Połącz z bazą danych
      $servername = "localhost"; // Twój serwer MySQL
      $username = "root"; // Twój użytkownik MySQL
      $password = ""; // Twoje hasło MySQL
      $dbname = "Users"; // Twoja nazwa bazy danych

      $conn = new mysqli($servername, $username, $password, $dbname);
      if ($conn->connect_error) {
        die("Błąd połączenia z bazą danych: " . $conn->connect_error);
      }

      // Pobierz produkty z koszyka wraz z nazwami z tabeli products
      $sql = "SELECT cart.*, products.name AS product_name FROM cart JOIN products ON cart.product_id = products.id";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
        // Wyświetl produkty w koszyku
        while ($row = $result->fetch_assoc()) {
          $productName = $row['product_name'];
          $productPrice = $row['price'];
          $quantity = $row['quantity'];
          $totalPrice = $productPrice * $quantity;

          echo "<tr>";
          echo "<td class='product-name'>$productName</td>";
          echo "<td>$productPrice zł</td>";
          echo "<td><input type='number' id='quantity-$productName' value='$quantity'></td>";
          echo "<td><button onclick=\"updateQuantity('$productName')\">Zatwierdź</button></td>";
          echo "<td><button onclick=\"removeFromCart('$productName')\">Usuń</button></td>";
          echo "</tr>";
        }
      } else {
        echo "<tr><td colspan='4'>Koszyk jest pusty.</td></tr>";
      }

      // Zamknij połączenie z bazą danych
      $conn->close();
      ?>
    </tbody>
    <tfoot>
      <tr>
        <th></th>
        <th colspan="2"></th>
        <th colspan="2">
          <?php
          // Połącz z bazą danych
          $conn = new mysqli($servername, $username, $password, $dbname);
          if ($conn->connect_error) {
            die("Błąd połączenia z bazą danych: " . $conn->connect_error);
          }

          // Pobierz sumę cen produktów w koszyku
          $sql = "SELECT SUM(price * quantity) AS total FROM cart";
          $result = $conn->query($sql);
          $row = $result->fetch_assoc();
          $total = $row['total'];
          echo "Suma:  $total zł";
          ?>
        </th>
      </tr>
    </tfoot>
  </table>
        </div>

  <script>
    function updateQuantity(productName) {
      var quantityInput = document.getElementById("quantity-" + productName);
      var newQuantity = quantityInput.value;

      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
          location.reload();
        }
      };
      xhttp.open("POST", "updateQuantity.php", true);
      xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      xhttp.send("product_name=" + productName + "&quantity=" + newQuantity);
    }
  </script>

  <script>
    function removeFromCart(productName) {
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
          location.reload();
        }
      };
      xhttp.open("POST", "removeFromCart.php", true);
      xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      xhttp.send("product_name=" + productName);
    }
  </script>

    <!-- Formularz dla składania zamówienia -->
    <form action="placeOrder.php" method="post">
      <label for="name">Imię:</label>
      <input type="text" id="name" name="name" required>

      <label for="address">Adres:</label>
      <input type="text" id="address" name="address" required>

      <label for="phone">Telefon:</label>
      <input type="text" id="phone" name="phone" required>

      <label for="delivery">Opcje dostawy:</label>
      <select id="delivery" name="delivery">
        <option value="Opcja 1">Sklep</option>
        <option value="Opcja 2">InPost</option>
        <option value="Opcja 3">Własny Kurier firmy</option>
      </select>

      <label for="payment">Opcje płatności:</label>
      <select id="payment" name="payment">
        <option value="Opcja 1">Swedbank</option>
        <option value="Opcja 2">Visa</option>
        <option value="Opcja 3">Gotówką</option>
      </select>

      <button type="submit">Złóż zamówienie</button>
    </form>

</body>
</html>
